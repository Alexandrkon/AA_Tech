/**
 * RxDroid - A Medication Reminder
 * Copyright (C) 2011-2014 Joseph Lehner <joseph.c.lehner@gmail.com>
 *
 *
 * RxDroid is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version. Additional terms apply (see LICENSE).
 *
 * RxDroid is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with RxDroid.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 */

package at.jclehner.rxdroid.util;

public final class Exceptions
{
	public static class UnexpectedValueInSwitch extends RuntimeException
	{
		private static final long serialVersionUID = 3223514077564332618L;

		public UnexpectedValueInSwitch() {
			super("Unexpected value in switch statement");
		}

		public UnexpectedValueInSwitch(long value) {
			super("Unexpected value in switch statement: " + value);
		}
	}

	private Exceptions() {}
}
